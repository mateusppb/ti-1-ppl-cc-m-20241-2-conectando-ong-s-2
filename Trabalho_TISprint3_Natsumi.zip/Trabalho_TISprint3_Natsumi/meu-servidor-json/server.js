const express = require('express');
const app = express();
const port = 3001;

// Adicionando cabeçalhos CORS
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); // Permitir solicitações de qualquer origem
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE'); // Permitir os métodos HTTP especificados
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization'); // Permitir os cabeçalhos especificados
  next();
});

// Dados JSON embutidos no código
const ongs = [
  {
    "id": 1,
    "nome": "ONG Exemplo",
    "local": "Rua das Flores, 123",
    "contato": "(11) 1234-5678"
  },
  {
    "id": 2,
    "nome": "ONG 1",
    "local": "Rua das Flores, 123",
    "contato": "(11) 1232-5678"
  }
];

// Middleware para analisar JSON
app.use(express.json());

// Rota para obter os dados
app.get('/api/ongs', (req, res) => {
  res.json(ongs);
});

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});